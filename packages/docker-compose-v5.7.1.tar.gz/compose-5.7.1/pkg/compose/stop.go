/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package compose

import (
	"context"
	"slices"
	"strings"

	"github.com/docker/compose/v5/internal/concurrency"
	"github.com/docker/compose/v5/internal/depgraph"
	"github.com/docker/compose/v5/pkg/api"
)

func (s *composeService) Stop(ctx context.Context, projectName string, options api.StopOptions) error {
	return Run(ctx, func(ctx context.Context) error {
		return s.stop(ctx, strings.ToLower(projectName), options, nil)
	}, "stop", s.events)
}

func (s *composeService) stop(ctx context.Context, projectName string, options api.StopOptions, event api.ContainerEventListener) error {
	containers, err := s.getContainers(ctx, projectName, oneOffExclude, true)
	if err != nil {
		return err
	}

	project, err := s.projectOrFromResources(ctx, options.Project, containers, projectName)
	if err != nil {
		return err
	}

	if len(options.Services) == 0 {
		options.Services = project.ServiceNames()
	}

	// shared across services — see restart.go's concurrency.NewLimiter comment
	// for why a per-service limiter alone isn't enough.
	limiter := concurrency.NewLimiter(s.maxConcurrency)

	return depgraph.InReverseDependencyOrder(ctx, project, func(c context.Context, service string) error {
		if !slices.Contains(options.Services, service) {
			return nil
		}
		serv := project.Services[service]
		// a provider service may still own a project container — the relay
		// deployed when it published endpoints — and the plugin's own stop
		// hook (if any) only concerns the provider's resource, so the
		// container is stopped the same way as for any other service.
		if err := s.stopContainers(ctx, &serv, containers.filter(isService(service)).filter(isNotOneOff), options.Timeout, event, limiter); err != nil {
			return err
		}
		if serv.Provider != nil {
			return s.runPlugin(ctx, project, serv, "stop")
		}
		return nil
	})
}
