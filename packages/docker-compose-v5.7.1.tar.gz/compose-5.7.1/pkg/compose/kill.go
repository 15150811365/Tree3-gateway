/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package compose

import (
	"context"
	"strings"

	"github.com/moby/moby/api/types/container"
	"github.com/moby/moby/client"

	"github.com/docker/compose/v5/internal/concurrency"
	"github.com/docker/compose/v5/internal/progress"
	"github.com/docker/compose/v5/pkg/api"
)

func (s *composeService) Kill(ctx context.Context, projectName string, options api.KillOptions) error {
	return Run(ctx, func(ctx context.Context) error {
		return s.kill(ctx, strings.ToLower(projectName), options)
	}, "kill", s.events)
}

func (s *composeService) kill(ctx context.Context, projectName string, options api.KillOptions) error {
	services := options.Services

	var containers Containers
	containers, err := s.getContainers(ctx, projectName, oneOffInclude, options.All, services...)
	if err != nil {
		return err
	}

	project, err := s.projectOrFromResources(ctx, options.Project, containers, projectName)
	if err != nil {
		return err
	}

	if !options.RemoveOrphans {
		containers = containers.filter(isService(project.ServiceNames()...))
	}
	if len(containers) == 0 {
		return api.ErrNoResources
	}

	return concurrency.ForEachBounded(ctx, s.maxConcurrency, containers, func(ctx context.Context, ctr container.Summary) error {
		eventName := getContainerProgressName(ctr)
		s.events.On(progress.New(eventName, api.Working, api.StatusKilling))
		_, err := s.apiClient().ContainerKill(ctx, ctr.ID, client.ContainerKillOptions{
			Signal: options.Signal,
		})
		if err != nil {
			s.events.On(progress.Error(eventName, "Error while Killing"))
			return err
		}
		s.events.On(progress.New(eventName, api.Done, api.StatusKilled))
		return nil
	})
}
