/*
   Copyright 2023 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package registry

import (
	"github.com/distribution/reference"
	clitypes "github.com/docker/cli/cli/config/types"
	"github.com/moby/moby/api/pkg/authconfig"
	registrytypes "github.com/moby/moby/api/types/registry"
)

const (
	// DefaultNamespace is the default namespace
	DefaultNamespace = "docker.io"
	// DefaultRegistryHost is the hostname for the default (Docker Hub) registry
	// used for pushing and pulling images. This hostname is hard-coded to handle
	// the conversion from image references without registry name (e.g. "ubuntu",
	// or "ubuntu:latest"), as well as references using the "docker.io" domain
	// name, which is used as canonical reference for images on Docker Hub, but
	// does not match the domain-name of Docker Hub's registry.
	DefaultRegistryHost = "registry-1.docker.io"
	// IndexHostname is the index hostname, used for authentication and image search.
	IndexHostname = "index.docker.io"
	// IndexServer is used for user auth and image search
	IndexServer = "https://" + IndexHostname + "/v1/"
	// IndexName is the name of the index
	IndexName = "docker.io"
	// StagingRegistryHost is the Docker Hub staging registry.
	StagingRegistryHost = "registry-1-stage.docker.io"
	// StagingIndexServer is the credentials key for StagingRegistryHost.
	StagingIndexServer = "https://" + StagingRegistryHost + "/"
	// DHIRegistryHost is the Docker Hardened Images registry.
	DHIRegistryHost = "dhi.io"
	// DHIIndexServer is the credentials key for DHIRegistryHost.
	DHIIndexServer = "https://" + DHIRegistryHost
)

// GetAuthConfigKey special-cases using the full index address of the official
// index as the AuthConfig key, and uses the (host)name[:port] for private indexes.
//
// It differs from the docker CLI configfile's own normalization by also
// mapping the registry host (registry-1.docker.io): OCI resolvers hand the
// credential callback the network host actually contacted, not the reference
// domain.
func GetAuthConfigKey(indexName string) string {
	if indexName == IndexName || indexName == IndexHostname || indexName == DefaultRegistryHost {
		return IndexServer
	}
	return indexName
}

// AuthProvider provides registry credentials for a registry hostname, as
// implemented by the docker CLI's configfile.
type AuthProvider interface {
	GetAuthConfig(registryHostname string) (clitypes.AuthConfig, error)
}

// AuthProviderFunc adapts a function to AuthProvider.
type AuthProviderFunc func(registryHostname string) (clitypes.AuthConfig, error)

// GetAuthConfig calls f.
func (f AuthProviderFunc) GetAuthConfig(registryHostname string) (clitypes.AuthConfig, error) {
	return f(registryHostname)
}

// EncodedAuth returns the credentials for the registry hosting the given
// image reference, base64-encoded as expected by the Docker API's
// X-Registry-Auth header. The configfile normalizes the Docker Hub domain to
// its canonical credentials key itself.
func EncodedAuth(ref reference.Named, cfg AuthProvider) (string, error) {
	auth, err := cfg.GetAuthConfig(reference.Domain(ref))
	if err != nil {
		return "", err
	}
	return authconfig.Encode(registrytypes.AuthConfig{
		Username:      auth.Username,
		Password:      auth.Password,
		Auth:          auth.Auth,
		ServerAddress: auth.ServerAddress,
		IdentityToken: auth.IdentityToken,
		RegistryToken: auth.RegistryToken,
	})
}
