/*
   Copyright 2026 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package images

import (
	"testing"

	"github.com/compose-spec/compose-go/v2/types"
	"github.com/containerd/errdefs"
	"github.com/moby/moby/api/types/image"
	"github.com/moby/moby/client"
	"go.uber.org/mock/gomock"
	"gotest.tools/v3/assert"

	"github.com/docker/compose/v5/internal/naming"
	compose "github.com/docker/compose/v5/pkg/api"
	"github.com/docker/compose/v5/pkg/mocks"
)

func TestImageBelongsToKnownService(t *testing.T) {
	project := &types.Project{
		Services:         types.Services{"web": {Name: "web"}},
		DisabledServices: types.Services{"worker": {Name: "worker"}},
	}
	for _, tc := range []struct {
		name            string
		service         string
		want            bool
		wantWithOrphans bool
	}{
		{name: "enabled", service: "web", want: true, wantWithOrphans: true},
		{name: "disabled", service: "worker"},
		{name: "undeclared", service: "old", wantWithOrphans: true},
		{name: "unlabeled", wantWithOrphans: true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var img image.Summary
			if tc.service != "" {
				img.Labels = map[string]string{compose.ServiceLabel: tc.service}
			}
			assert.Equal(t, ImageBelongsToKnownService(project, false, img), tc.want)
			assert.Equal(t, ImageBelongsToKnownService(project, true, img), tc.wantWithOrphans)
		})
	}
}

// TestRemoveDanglingImages_FiltersKeepsAndToleratesFailures guards the
// shared helper used by both `down --rmi` and `watch --prune`: images the
// keep predicate spares must never be removed; an image already gone (a
// benign race with something else removing it concurrently) or still in
// use (the same tolerance down already gives a tagged image in
// the same situation) is tolerated and not reported as a failure; a
// genuine removal error doesn't stop the others, but is joined into the
// returned error (preserving the actual daemon error, not just the image
// ID) for callers that need to surface it.
func TestRemoveDanglingImages_FiltersKeepsAndToleratesFailures(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()

	apiClient := mocks.NewMockAPIClient(mockCtrl)
	svc := New(&fakeBackend{apiClient: apiClient})

	apiClient.EXPECT().ImageList(gomock.Any(), client.ImageListOptions{
		Filters: naming.ProjectFilter("prj").Add("dangling", "true"),
	}).Return(client.ImageListResult{Items: []image.Summary{
		{ID: "sha256:keep"},
		{ID: "sha256:removed"},
		{ID: "sha256:already-gone"},
		{ID: "sha256:in-use"},
		{ID: "sha256:fails"},
	}}, nil)
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:removed", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, nil)
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:already-gone", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, errdefs.ErrNotFound.WithMessage("already removed"))
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:in-use", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, errdefs.ErrConflict.WithMessage("image is being used"))
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:fails", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, errdefs.ErrPermissionDenied.WithMessage("permission denied"))
	// no expectation for "sha256:keep" — a call to ImageRemove for it fails the test

	keep := func(img image.Summary) bool { return img.ID == "sha256:keep" }
	removed, err := svc.RemoveDanglingImages(t.Context(), "prj", keep)
	assert.DeepEqual(t, removed, []string{"sha256:removed"})
	assert.ErrorContains(t, err, "sha256:fails")
	assert.ErrorContains(t, err, "permission denied")
}

// TestRemoveImages_BucketsStillInUseSeparatelyFromRemoved guards a
// regression caught by review: an image still in use (goal NOT achieved)
// must land in its own return bucket, not be folded into removed — a caller
// aggregating several images (down's removal of dangling images) needs the distinction
// to report the batch honestly. An already-gone image reaches the goal like
// an actual removal and a genuine failure is joined into err, so neither is
// exercised here beyond not corrupting the removed/stillInUse buckets.
func TestRemoveImages_BucketsStillInUseSeparatelyFromRemoved(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()

	apiClient := mocks.NewMockAPIClient(mockCtrl)
	svc := New(&fakeBackend{apiClient: apiClient})

	images := []image.Summary{
		{ID: "sha256:removed"},
		{ID: "sha256:already-gone"},
		{ID: "sha256:in-use"},
		{ID: "sha256:fails"},
	}
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:removed", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, nil)
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:already-gone", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, errdefs.ErrNotFound.WithMessage("already removed"))
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:in-use", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, errdefs.ErrConflict.WithMessage("image is being used"))
	apiClient.EXPECT().ImageRemove(gomock.Any(), "sha256:fails", client.ImageRemoveOptions{}).
		Return(client.ImageRemoveResult{}, errdefs.ErrPermissionDenied.WithMessage("permission denied"))

	removed, stillInUse, err := svc.RemoveImages(t.Context(), images, nil)
	assert.DeepEqual(t, removed, []string{"sha256:removed"})
	assert.DeepEqual(t, stillInUse, []string{"sha256:in-use"})
	assert.ErrorContains(t, err, "sha256:fails")
	assert.ErrorContains(t, err, "permission denied")
}

// TestRemoveDanglingImages_NoneFound guards that an empty dangling-image
// list is a no-op: no removal calls, no error.
func TestRemoveDanglingImages_NoneFound(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()

	apiClient := mocks.NewMockAPIClient(mockCtrl)
	svc := New(&fakeBackend{apiClient: apiClient})

	apiClient.EXPECT().ImageList(gomock.Any(), client.ImageListOptions{
		Filters: naming.ProjectFilter("prj").Add("dangling", "true"),
	}).Return(client.ImageListResult{}, nil)

	removed, err := svc.RemoveDanglingImages(t.Context(), "prj", func(image.Summary) bool { return false })
	assert.NilError(t, err)
	assert.Equal(t, len(removed), 0)
}

// TestImagesToPrune_RejectsInvalidMode guards the one check ImagesToPrune
// still makes on its own: down() validates options.Images upfront (see
// TestDownRejectsInvalidImagePruneModeUpfront), but Pruner is exported
// and can be driven directly with a hand-built PruneOptions that
// bypasses that check — this is the defense-in-depth path Valid() must
// still reject. No API client call is expected: an invalid mode must be
// rejected before any engine call is made.
func TestImagesToPrune_RejectsInvalidMode(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()

	apiClient := mocks.NewMockAPIClient(mockCtrl)

	pruner := NewPruner(apiClient, &types.Project{Name: "prj"}, nil)
	_, err := pruner.ImagesToPrune(t.Context(), PruneOptions{Mode: compose.ImagePruneMode("bogus")})
	assert.ErrorContains(t, err, "unsupported image prune mode: bogus")
}
