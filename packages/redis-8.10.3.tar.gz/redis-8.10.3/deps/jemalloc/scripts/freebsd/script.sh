#!/bin/tcsh

gmake check
