import type { ChildProcess } from 'node:child_process'
// Screenshot generation script for CI
// Usage: pnpm screenshot
import { spawn } from 'node:child_process'
import * as fs from 'node:fs'
import { chromium } from 'playwright'

const PORT = process.env.PORT || '4199'
const BASE_URL = `http://localhost:${PORT}`
const OUTPUT_DIR = process.env.OUTPUT_DIR || 'docs'
const PC_DIR = `${OUTPUT_DIR}/pc`
const MOBILE_DIR = `${OUTPUT_DIR}/mobile`

interface PageConfig {
  name: string
  path: string // Hash route path (e.g., '/#/overview')
  waitFor: string
}

// Pages to capture - same for both desktop and mobile
const PAGES: PageConfig[] = [
  {
    name: 'overview',
    path: '/#/overview',
    waitFor: '.overview-stat-card', // Overview page stat cards
  },
  {
    name: 'proxies',
    path: '/#/proxies',
    waitFor: 'button', // Proxies page buttons
  },
  {
    name: 'connections',
    path: '/#/connections',
    waitFor: 'table', // Connections table
  },
  {
    name: 'rules',
    path: '/#/rules',
    waitFor: 'button', // Rules page buttons
  },
  {
    name: 'logs',
    path: '/#/logs',
    waitFor: 'table', // Logs table
  },
  {
    name: 'config',
    path: '/#/config',
    waitFor: '.config-card', // Config cards
  },
]

const DESKTOP_VIEWPORT = { width: 1920, height: 1080 }
const MOBILE_VIEWPORT = { width: 390, height: 844 } // iPhone 14 Pro size

// Check if server is ready by making HTTP request
async function waitForServer(maxAttempts = 30): Promise<void> {
  for (let i = 0; i < maxAttempts; i++) {
    try {
      const response = await fetch(BASE_URL)

      if (response.ok) {
        console.log(`Server is ready at ${BASE_URL}`)

        return
      }
    } catch {
      // Server not ready yet, wait and retry
    }

    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  throw new Error('Server failed to start within timeout')
}

// Start nuxt preview server
function startServer(): ChildProcess {
  console.log(`Starting preview server on port ${PORT}...`)

  const server = spawn('npx', ['nuxt', 'preview'], {
    stdio: 'inherit',
    shell: true,
    detached: true, // Create a new process group
    env: {
      ...process.env,
      PORT,
    },
  })

  server.on('error', (err) => {
    console.error('Server error:', err)
  })

  return server
}

// Stop the server gracefully
function stopServer(server: ChildProcess): Promise<void> {
  return new Promise((resolve) => {
    if (!server.pid) {
      resolve()

      return
    }

    console.log('Stopping preview server...')

    server.on('close', () => {
      console.log('Server stopped')
      resolve()
    })

    // Kill the entire process group (negative PID)
    try {
      process.kill(-server.pid, 'SIGTERM')
    } catch {
      // Process might already be dead
    }

    // Force kill after 3 seconds if still running
    setTimeout(() => {
      try {
        process.kill(-server.pid!, 'SIGKILL')
      } catch {
        // Process might already be dead
      }

      resolve()
    }, 3000)
  })
}

async function takeScreenshots() {
  console.log('Starting screenshot generation...')
  console.log(`Base URL: ${BASE_URL}`)
  console.log(`Output directory: ${OUTPUT_DIR}`)

  // Ensure output directories exist
  if (!fs.existsSync(PC_DIR)) {
    fs.mkdirSync(PC_DIR, { recursive: true })
  }

  if (!fs.existsSync(MOBILE_DIR)) {
    fs.mkdirSync(MOBILE_DIR, { recursive: true })
  }

  const browser = await chromium.launch({
    headless: true,
  })

  // Create desktop context
  const desktopContext = await browser.newContext({
    viewport: DESKTOP_VIEWPORT,
    deviceScaleFactor: 2,
  })

  // Create mobile context
  const mobileContext = await browser.newContext({
    viewport: MOBILE_VIEWPORT,
    deviceScaleFactor: 3,
    isMobile: true,
    hasTouch: true,
  })

  const desktopPage = await desktopContext.newPage()
  const mobilePage = await mobileContext.newPage()

  // Setup localStorage with mock endpoint to bypass auth redirect
  // Must be done before first navigation, then reload to apply
  const setupLocalStorage = async (
    page: Awaited<ReturnType<typeof desktopContext.newPage>>,
  ) => {
    // Navigate to base URL first to set localStorage on correct origin
    await page.goto(BASE_URL, { waitUntil: 'domcontentloaded' })
    await page.evaluate(() => {
      localStorage.setItem('curTheme', '"dark"')
      // Set a mock endpoint to prevent redirect to setup page
      // Note: VueUse's useLocalStorage<string> stores raw strings, not JSON-serialized
      // But useLocalStorage<T[]> expects JSON-serialized arrays
      localStorage.setItem('selectedEndpoint', 'mock-endpoint')
      localStorage.setItem(
        'endpointList',
        JSON.stringify([
          { id: 'mock-endpoint', url: 'http://127.0.0.1:9090', secret: '' },
        ]),
      )
      // Set collapsedMap to expand all proxy groups by default
      // true = expanded, false/undefined = collapsed
      localStorage.setItem(
        'collapsedMap',
        JSON.stringify({
          'Auto Select': true,
          Proxy: true,
          Streaming: true,
          'AI Services': true,
          'Provider A': true,
          'Provider B': true,
        }),
      )
    })
    // Reload to apply localStorage changes to Pinia store
    await page.reload({ waitUntil: 'domcontentloaded' })
  }

  // Setup localStorage for both contexts
  await setupLocalStorage(desktopPage)
  await setupLocalStorage(mobilePage)

  // Take screenshots for each page in both desktop and mobile viewports
  for (const pageConfig of PAGES) {
    // Desktop screenshot
    await captureScreenshot(
      desktopPage,
      pageConfig,
      PC_DIR,
      pageConfig.name,
      '🖥️',
    )

    // Mobile screenshot
    await captureScreenshot(
      mobilePage,
      pageConfig,
      MOBILE_DIR,
      pageConfig.name,
      '📱',
    )
  }

  await desktopContext.close()
  await mobileContext.close()
  await browser.close()
  console.log('Screenshot generation complete!')
}

async function captureScreenshot(
  page: Awaited<
    ReturnType<typeof chromium.launch>
  >['newPage'] extends () => Promise<infer P>
    ? P
    : never,
  config: PageConfig,
  outputDir: string,
  filename: string,
  label: string,
) {
  console.log(`${label} Taking screenshot: ${outputDir}/${filename}.png`)

  try {
    // Navigate directly to the hash route
    await page.goto(`${BASE_URL}${config.path}`, {
      waitUntil: 'domcontentloaded',
      timeout: 30000,
    })

    // Wait for page to stabilize
    await page.waitForTimeout(2000)

    // Try to wait for specific element, but don't fail if not found
    if (config.waitFor) {
      try {
        await page.waitForSelector(config.waitFor, { timeout: 5000 })
      } catch {
        console.log(
          `  (element ${config.waitFor} not found, continuing anyway)`,
        )
      }
    }

    // Log current URL for debugging
    const currentUrl = page.url()
    console.log(`  URL: ${currentUrl}`)

    // Additional wait for animations
    await page.waitForTimeout(500)

    await page.screenshot({
      path: `${outputDir}/${filename}.png`,
      type: 'png',
      fullPage: false,
    })

    console.log(`✓ Saved ${outputDir}/${filename}.png`)
  } catch (error) {
    console.error(`✗ Failed to capture ${filename}:`, error)
  }
}

// Main entry point
async function main() {
  let server: ChildProcess | null = null

  try {
    // Start the preview server
    server = startServer()

    // Wait for server to be ready
    await waitForServer()

    // Take screenshots
    await takeScreenshots()
  } catch (error) {
    console.error('Screenshot generation failed:', error)
    process.exitCode = 1
  } finally {
    // Always stop the server
    if (server) {
      await stopServer(server)
    }
  }
}

main()
