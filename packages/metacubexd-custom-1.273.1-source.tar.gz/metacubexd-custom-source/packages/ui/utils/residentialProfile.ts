export interface ResidentialListenerInput {
  label: string
  name: string
  listen: string
  port: string
}

export interface ResidentialProfileInput {
  host: string
  port: string
  username: string
  password: string
  chainEnabled: boolean
  subscriptionUrl: string
  listeners: ResidentialListenerInput[]
}

export type ResidentialProfileErrorCode =
  | 'host'
  | 'proxyPort'
  | 'credentials'
  | 'subscription'
  | 'listenerRequired'
  | 'listenerName'
  | 'listenerAddress'
  | 'listenerPort'
  | 'duplicateListenerName'
  | 'duplicateListenerPort'

export class ResidentialProfileError extends Error {
  constructor(
    public readonly code: ResidentialProfileErrorCode,
    public readonly row?: number,
  ) {
    super(code)
    this.name = 'ResidentialProfileError'
  }
}

const RESIDENTIAL_NODE = 'Tree3-Residential'
const AIRPORT_PROVIDER = 'Tree3-Airport'
const AIRPORT_GROUP = 'Tree3-Airport-Hop'
const CONTROL_CHAR = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/

function portNumber(value: string): number | undefined {
  const text = value.trim()
  if (!/^\d{1,5}$/.test(text)) return undefined
  const port = Number(text)
  return port >= 1 && port <= 65535 ? port : undefined
}

function normalizeHost(value: string): string | undefined {
  const host = value.trim()
  if (!host || CONTROL_CHAR.test(host) || /[\s/@?#\\%]/.test(host))
    return undefined

  if (
    (host.includes('[') || host.includes(']')) &&
    !(host.startsWith('[') && host.endsWith(']'))
  )
    return undefined

  const candidate =
    host.includes(':') && !host.startsWith('[') ? `[${host}]` : host
  try {
    const parsed = new URL(`http://${candidate}/`)
    const hostname = parsed.hostname
    if (!hostname || parsed.port || parsed.pathname !== '/') return undefined
    if (hostname.startsWith('[')) return hostname.slice(1, -1)
    if (!/^[a-z\d_.-]+$/i.test(hostname)) return undefined
    return hostname
  } catch {
    return undefined
  }
}

function normalizeListen(value: string): string | undefined {
  const address = value.trim()
  const normalized = normalizeHost(address)
  if (!normalized) return undefined
  if (normalized.includes(':')) return normalized
  return /^(?:\d{1,3}\.){3}\d{1,3}$/.test(address) ? normalized : undefined
}

function validCredentials(username: string, password: string): boolean {
  return (
    !CONTROL_CHAR.test(username) &&
    !CONTROL_CHAR.test(password) &&
    Boolean(username) === Boolean(password)
  )
}

export function parseResidentialSocksUrl(value: string): {
  host: string
  port: string
  username: string
  password: string
} {
  try {
    const text = value.trim()
    if (/[\s\\?#]/.test(text) || CONTROL_CHAR.test(text)) throw new Error()
    const url = new URL(text)
    if (url.protocol !== 'socks5:' || (url.pathname && url.pathname !== '/'))
      throw new Error()

    const host = normalizeHost(url.hostname)
    const port = portNumber(url.port)
    const username = decodeURIComponent(url.username)
    const password = decodeURIComponent(url.password)
    if (!host || port === undefined || !validCredentials(username, password))
      throw new Error()

    return { host, port: String(port), username, password }
  } catch {
    throw new Error('invalid_socks5_url')
  }
}

function quote(value: string): string {
  return JSON.stringify(value).replace(/[\u007f-\u009f\u2028\u2029]/g, (char) =>
    `\\u${char.charCodeAt(0).toString(16).padStart(4, '0')}`,
  )
}

function checkSubscription(value: string): string {
  const text = value.trim()
  try {
    if (CONTROL_CHAR.test(text) || !/^https?:\/\//i.test(text)) throw new Error()
    const url = new URL(text)
    if (!url.hostname || (url.protocol !== 'https:' && url.protocol !== 'http:'))
      throw new Error()
    return text
  } catch {
    throw new ResidentialProfileError('subscription')
  }
}

export function buildResidentialProfile(input: ResidentialProfileInput): string {
  const host = normalizeHost(input.host)
  if (!host) throw new ResidentialProfileError('host')
  const port = portNumber(input.port)
  if (port === undefined) throw new ResidentialProfileError('proxyPort')
  if (!validCredentials(input.username, input.password))
    throw new ResidentialProfileError('credentials')
  if (!input.listeners.length) throw new ResidentialProfileError('listenerRequired')

  const subscription = input.chainEnabled
    ? checkSubscription(input.subscriptionUrl)
    : undefined
  const names = new Set<string>()
  const ports = new Set<number>()
  const listeners = input.listeners.map((item, index) => {
    const row = index + 1
    const name = item.name.trim()
    if (!name || CONTROL_CHAR.test(name))
      throw new ResidentialProfileError('listenerName', row)
    if (names.has(name))
      throw new ResidentialProfileError('duplicateListenerName', row)
    const listen = normalizeListen(item.listen)
    if (!listen) throw new ResidentialProfileError('listenerAddress', row)
    const listenerPort = portNumber(item.port)
    if (listenerPort === undefined)
      throw new ResidentialProfileError('listenerPort', row)
    if (ports.has(listenerPort))
      throw new ResidentialProfileError('duplicateListenerPort', row)
    names.add(name)
    ports.add(listenerPort)
    return { label: item.label.trim(), name, listen, port: listenerPort }
  })

  const lines = ['mode: rule', 'tun:', '  enable: false']
  if (subscription !== undefined) {
    lines.push(
      '',
      'proxy-providers:',
      `  ${quote(AIRPORT_PROVIDER)}:`,
      '    type: http',
      `    url: ${quote(subscription)}`,
      '    interval: 3600',
      '    proxy: DIRECT',
      '    header:',
      '      User-Agent:',
      '        - "clash.meta"',
      '',
      'proxy-groups:',
      `  - name: ${quote(AIRPORT_GROUP)}`,
      '    type: select',
      '    use:',
      `      - ${quote(AIRPORT_PROVIDER)}`,
      '    empty-fallback: REJECT',
    )
  }
  lines.push(
    '',
    'proxies:',
    `  - name: ${quote(RESIDENTIAL_NODE)}`,
    '    type: socks5',
    `    server: ${quote(host)}`,
    `    port: ${port}`,
  )
  if (input.username) {
    lines.push(
      `    username: ${quote(input.username)}`,
      `    password: ${quote(input.password)}`,
    )
  }
  if (subscription !== undefined)
    lines.push(`    dialer-proxy: ${quote(AIRPORT_GROUP)}`)

  lines.push('', 'listeners:')
  for (const listener of listeners) {
    if (listener.label) lines.push(`  # ${quote(listener.label)}`)
    lines.push(
      `  - name: ${quote(listener.name)}`,
      '    type: http',
      `    listen: ${quote(listener.listen)}`,
      `    port: ${listener.port}`,
      `    proxy: ${quote(RESIDENTIAL_NODE)}`,
    )
  }
  lines.push('', 'rules:', '  - MATCH,REJECT', '')
  return lines.join('\n')
}
